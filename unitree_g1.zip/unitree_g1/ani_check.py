import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.animation import FuncAnimation
import csv

L1 = 1.0
L2 = 1.0

# CSVファイルからデータを読み取る関数
def read_csv_data(csv_file_path):
    time_data = []
    angle_data = []

    with open(csv_file_path, 'r', newline='') as csvfile:
        csv_reader = csv.reader(csvfile)
        next(csv_reader)  # ヘッダー行をスキップ
        for row in csv_reader:
            time_data.append(float(row[0]))  # Timeデータを読み取る
            angle_data.append(float(row[1]))  # Radianの角度データをそのまま読み取る

    return time_data, angle_data

# 4つのCSVファイルのパス
csv_paths = {
    "shoulder_pitch": "shoulder_pitch_actuator_results.csv",
    "shoulder_roll": "shoulder_roll_actuator_results.csv",
    "shoulder_yaw": "shoulder_yaw_actuator_results.csv",
    "elbow": "elbow_actuator_results.csv"
}

# 各自由度のデータを読み込む
data = {}
for joint, path in csv_paths.items():
    time_data, angle_data = read_csv_data(path)
    data[joint] = {
        "time": time_data,
        "angle": angle_data
    }

# アニメーションの初期化関数
def init():
    link1.set_data([], [])
    link1.set_3d_properties([])
    link2.set_data([], [])
    link2.set_3d_properties([])
    return link1, link2

# アニメーションの更新関数
def update(frame):
    # 各角度を取得
    theta_roll = data["shoulder_roll"]["angle"][frame]
    theta_pitch = data["shoulder_pitch"]["angle"][frame]
    theta_yaw = data["shoulder_yaw"]["angle"][frame]
    theta_elbow = data["elbow"]["angle"][frame]

    # リンク1の座標計算
    x1 = L1 * (np.cos(theta_roll) * np.cos(theta_yaw) * np.cos(theta_pitch) - np.sin(theta_roll) * np.sin(theta_yaw))
    y1 = L1 * (np.cos(theta_roll) * np.sin(theta_yaw) * np.cos(theta_pitch) + np.sin(theta_roll) * np.cos(theta_yaw))
    z1 = L1 * np.sin(theta_pitch)
    link1.set_data([0, x1], [0, y1])
    link1.set_3d_properties([0, z1])

    # リンク2の座標計算
    x2 = x1 + L2 * (np.cos(theta_roll) * np.cos(theta_yaw) * np.cos(theta_pitch + theta_elbow) - np.sin(theta_roll) * np.sin(theta_yaw))
    y2 = y1 + L2 * (np.cos(theta_roll) * np.sin(theta_yaw) * np.cos(theta_pitch + theta_elbow) + np.sin(theta_roll) * np.cos(theta_yaw))
    z2 = z1 + L2 * np.sin(theta_pitch + theta_elbow)
    link2.set_data([x1, x2], [y1, y2])
    link2.set_3d_properties([z1, z2])

    return link1, link2


# アニメーションの設定
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.set_xlim(-2.5, 2.5)
ax.set_ylim(-2.5, 2.5)
ax.set_zlim(-2.5, 2.5)
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')
link1, = ax.plot([], [], [], lw=2, label='Link 1')
link2, = ax.plot([], [], [], lw=2, label='Link 2')
ax.legend()

# アニメーションの作成
num_frames = len(data["shoulder_pitch"]["time"])
ani = FuncAnimation(fig, update, frames=num_frames, init_func=init, blit=False, interval=2)

# アニメーションをMP4形式で保存
ani.save('animation_4dof_3d.mp4', writer='Pillow', fps=100)
plt.show()
