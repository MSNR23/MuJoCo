import numpy as np

def compute_reward(qpos, qvel, cumulative_energy):
    """
    報酬を計算する関数
    :param qpos: 関節位置 (array)
    :param qvel: 関節速度 (array)
    :param cumulative_energy: 累積消費エネルギー (float)
    :return: 報酬値 (float)
    """
    hand_velocity = np.linalg.norm(qvel[:3])  # 手先速度の計算（仮想的に先頭3成分を使用）
    target_angle = 45  # 目標投射角度
    current_angle = np.degrees(np.arctan2(qvel[1], qvel[0]))
    angle_reward = max(0, 1 - abs(current_angle - target_angle) / target_angle)
    reward = hand_velocity * angle_reward - 0.001 * cumulative_energy  # ペナルティ付き報酬
    return reward
