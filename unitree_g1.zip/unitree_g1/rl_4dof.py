import mujoco
import numpy as np
import os
from state import digitize_state
from action import get_action, get_torque
from reward import compute_reward

# MuJoCoモデルの読み込み
MODEL_XML_PATH = "g1.xml"  # XMLファイルのパス
model = mujoco.MjModel.from_xml_path(MODEL_XML_PATH)
data = mujoco.MjData(model)

# 学習パラメータ
num_episodes = 5000
max_steps = 2000
num_q1_bins = 5
num_q2_bins = 5
num_q3_bins = 5
num_q4_bins = 5
num_q1_dot_bins = 4
num_q2_dot_bins = 4
num_q3_dot_bins = 4
num_q4_dot_bins = 4
num_actions = 81  # 行動数
alpha = 0.1
gamma = 0.9
max_torque = 20

# Qテーブルの初期化
Q = np.zeros((num_q1_bins, num_q2_bins, num_q3_bins, num_q4_bins, num_q1_dot_bins, num_q2_dot_bins, num_q3_dot_bins, num_q4_dot_bins, num_actions))

def bins(clip_min, clip_max, num):
    return np.linspace(clip_min, clip_max, num + 1)[1:-1]

# 状態の離散化関数
def digitize_state(q1, q2, q3, q4,q1_dot, q2_dot, q3_dot, q4_dot, num_q1_bins, num_q2_bins, num_q3_bins, num_q4_bins, num_q1_dot_bins, num_q2_dot_bins, num_q3_dot_bins, num_q4_dot_bins):
    digitized = [np.digitize(q1, bins = bins(-np.pi, 50 * np.pi / 180, num_q1_bins)),
                 np.digitize(q2, bins = bins(-np.pi, 0, num_q2_bins)),
                 np.digitize(q3, bins = bins(-60 * np.pi / 180, 80 * np.pi / 180, num_q3_bins)),
                 np.digitize(q4, bins = bins(-60 * np.pi / 180, 90 * np.pi / 180, num_q4_bins)),
                 np.digitize(q1_dot, bins = bins(-10.0, 10.0, num_q1_dot_bins)),
                 np.digitize(q2_dot, bins = bins(-10.0, 10.0, num_q2_dot_bins)),
                 np.digitize(q3_dot, bins = bins(-10.0, 10.0, num_q3_dot_bins)),
                 np.digitize(q4_dot, bins = bins(-10.0, 10.0, num_q4_dot_bins))]

    return digitized[0], digitized[1], digitized[2], digitized[3], digitized[4], digitized[5], digitized[6], digitized[7]


# 結果保存ディレクトリ
output_dir = "q_learning_results"
os.makedirs(output_dir, exist_ok=True)

# Q学習メインループ
for episode in range(num_episodes):
    mujoco.mj_resetData(model, data)  # シミュレーションをリセット
    cumulative_energy = 0
    state = digitize_state(q1, q2, q3, q4,q1_dot, q2_dot, q3_dot, q4_dot, num_q1_bins, num_q2_bins, num_q3_bins, num_q4_bins, num_q1_dot_bins, num_q2_dot_bins, num_q3_dot_bins, num_q4_dot_bins)
    action = get_action(Q, state, episode, num_actions)

    for step in range(max_steps):
        # 行動に基づいてトルクを適用
        torques = get_torque(action, max_torque)
        data.ctrl[:] = torques
        mujoco.mj_step(model, data)

        # 報酬の計算
        reward = compute_reward(data.qpos, data.qvel, cumulative_energy)
        cumulative_energy += np.sum(np.abs(torques) * np.abs(data.qvel) * model.opt.timestep)

        # 次状態を取得し離散化
        next_state = digitize_state(data.qpos, data.qvel, num_bins)
        next_action = get_action(Q, next_state, episode, num_actions)

        # Qテーブルの更新
        Q[tuple(state)][action] += alpha * (
            reward + gamma * np.max(Q[tuple(next_state)]) - Q[tuple(state)][action]
        )

        # 状態と行動を更新
        state, action = next_state, next_action

        # 終了条件（例：報酬が十分大きい場合）
        if reward > 100:
            break

    print(f"Episode {episode + 1}/{num_episodes} completed.")

# Qテーブルの保存
np.save(os.path.join(output_dir, "Q_table.npy"), Q)
print("Q-table saved!")
