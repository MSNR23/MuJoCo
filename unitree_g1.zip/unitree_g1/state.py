import numpy as np

def bins(clip_min, clip_max, num):
    return np.linspace(clip_min, clip_max, num + 1)[1:-1]

# 状態の離散化関数
def digitize_state(q1, q2, q3, q4,q1_dot, q2_dot, q3_dot, q4_dot, num_q1_bins, num_q2_bins, num_q3_bins, num_q4_bins, num_q1_dot_bins, num_q2_dot_bins, num_q3_dot_bins, num_q4_dot_bins):
    digitized = [np.digitize(q1, bins = bins(-np.pi, 50 * np.pi / 180, num_q1_bins)),
                 np.digitize(q2, bins = bins(-np.pi, 0, num_q2_bins)),
                 np.digitize(q3, bins = bins(-60 * np.pi / 180, 80 * np.pi / 180, num_q3_bins)),
                 np.digitize(q4, bins = bins(-60 * np.pi / 180, 90 * np.pi / 180, num_q4_bins)),
                 np.digitize(q1_dot, bins = bins(-10.0, 10.0, num_q1_dot_bins)),
                 np.digitize(q2_dot, bins = bins(-10.0, 10.0, num_q2_dot_bins)),
                 np.digitize(q3_dot, bins = bins(-10.0, 10.0, num_q3_dot_bins)),
                 np.digitize(q4_dot, bins = bins(-10.0, 10.0, num_q4_dot_bins))]

    return digitized[0], digitized[1], digitized[2], digitized[3], digitized[4], digitized[5], digitized[6], digitized[7]
