import numpy as np

def get_action(Q, state, episode, num_actions):
    """
    ε-greedy法で行動を選択
    :param Q: Qテーブル (ndarray)
    :param state: 現在の状態 (list)
    :param episode: エピソード番号 (int)
    :param num_actions: 行動の数 (int)
    :return: 選択された行動 (int)
    """
    epsilon = 0.5 * (0.99 ** (episode + 1))  # εをエピソードごとに減衰
    if np.random.rand() < epsilon:
        return np.random.choice(num_actions)  # ランダムに行動を選択
    else:
        return np.argmax(Q[tuple(state)])  # 最大のQ値を持つ行動を選択

def get_torque(action, max_torque, num_joints=4):
    """
    行動インデックスを関節トルクに変換
    :param action: 行動インデックス (int)
    :param max_torque: 最大トルク (float)
    :param num_joints: 関節の数 (int)
    :return: 各関節のトルク (ndarray)
    """
    torques = []
    for i in range(num_joints):
        idx = (action // (3**i)) % 3
        if idx == 0:
            torques.append(-max_torque)
        elif idx == 1:
            torques.append(0)
        else:
            torques.append(max_torque)
    return np.array(torques)
