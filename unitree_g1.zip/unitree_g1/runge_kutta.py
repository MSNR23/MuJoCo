import mujoco
import mujoco.viewer as viewer
import numpy as np
import time
import csv

# モデルのパス
model_path = "g1.xml"

# MuJoCoモデルのロード
model = mujoco.MjModel.from_xml_path(model_path)
data = mujoco.MjData(model)

# アクチュエータ名とインデックスを設定
actuator_names = [
    "shoulder_pitch_actuator",
    "shoulder_roll_actuator",
    "shoulder_yaw_actuator",
    "elbow_actuator",
]

# 各アクチュエータ名に対応するインデックスを取得
actuator_indices = []
for name in actuator_names:
    for i in range(model.nu):
        if mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_ACTUATOR, i) == name:
            actuator_indices.append(i)
            break
if len(actuator_indices) != len(actuator_names):
    raise ValueError("Some actuators not found in the model.")

# 各自由度ごとにCSVファイルを準備
csv_files = {}
writers = {}
for name in actuator_names:
    file_name = f"{name}_results.csv"
    csv_files[name] = open(file_name, mode="w", newline="")
    writers[name] = csv.writer(csv_files[name])
    writers[name].writerow(["time", "angle", "angular_velocity", "torque"])

# ルンゲクッタ法のステップサイズ
dt = 0.01  # 2msステップ

def runge_kutta_step(model, data, dt):
    """
    ルンゲクッタ法を1ステップ実行
    """
    mujoco.mj_step(model, data, nstep=1)

# トルクをゼロに設定
def apply_zero_torques(data):
    """
    全自由度のトルクをゼロに設定
    """
    data.ctrl[:] = 0

# ビューアを起動
with viewer.launch_passive(model, data) as sim_viewer:
    print("MuJoCo Viewer launched in passive mode.")
    print("Press Ctrl+C to exit the viewer...")

    # 初期姿勢の設定（ラジアン単位）
    # 順番はモデル内のジョイント順に対応
    initial_positions = [
        np.deg2rad(0),  # 肩ピッチ（45度）
        np.deg2rad(-90),  # 肩ロール（30度）
        np.deg2rad(-20), # 肩ヨー（-20度）
        np.deg2rad(15),  # 肘（15度）
    ]

    # 初期姿勢を設定
    data.qpos[:len(initial_positions)] = initial_positions

    simulation_time = 0  # シミュレーション時間
    max_time = 20  # シミュレーションを5秒間実行

    try:
        while sim_viewer.is_running() and simulation_time < max_time:
            # トルクをゼロに設定
            apply_zero_torques(data)

            # 現在の状態を取得
            for i, joint_name in enumerate(actuator_names):
                joint_qpos = data.qpos[i] if i < len(data.qpos) else 0
                joint_qvel = data.qvel[i] if i < len(data.qvel) else 0
                torque = data.ctrl[actuator_indices[i]] if i < len(actuator_indices) else 0

                # 各自由度ごとのCSVに書き込む
                writers[joint_name].writerow([simulation_time, joint_qpos, joint_qvel, torque])

            # ルンゲクッタ法で1ステップ進める
            runge_kutta_step(model, data, dt)

            # ビューアを同期
            sim_viewer.sync()

            # 時間を更新
            simulation_time += dt

    except KeyboardInterrupt:
        print("Exiting Viewer.")

# CSVファイルを閉じる
for file in csv_files.values():
    file.close()

print("Simulation complete. Results saved to individual CSV files.")
