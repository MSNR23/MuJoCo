import mujoco
import os

# 正しいパスを指定
model_path = "/home/k-ito/.mujoco/mujoco-3.2.6-linux-x86_64/mujoco-3.2.6/model/humanoid/humanoid.xml"
if not os.path.exists(model_path):
    raise FileNotFoundError(f"モデルファイルが見つかりません: {model_path}")

# Mujocoモデルをロード
model = mujoco.MjModel.from_xml_path(model_path)
data = mujoco.MjData(model)

print("Mujocoモデルが正常にロードされました！")
